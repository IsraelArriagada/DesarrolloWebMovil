/* ===== Craft & Beer — lógica del sitio ===== */

/* ---------- Carrito ---------- */
let carrito = JSON.parse(localStorage.getItem("carritoCraftBeer")) || [];

const contadorCarrito = document.getElementById("contadorCarrito");
const btnCarrito = document.getElementById("btnCarrito");
const cerrarCarrito = document.getElementById("cerrarCarrito");
const carritoPanel = document.getElementById("carritoPanel");
const contenidoCarrito = document.getElementById("contenidoCarrito");

function guardarCarrito() {
  localStorage.setItem("carritoCraftBeer", JSON.stringify(carrito));
}

function actualizarContador() {
  if (!contadorCarrito) return;
  const totalItems = carrito.length;
  contadorCarrito.textContent = totalItems;
  contadorCarrito.classList.toggle("scale-0", totalItems === 0);
}

function mostrarCarrito() {
  if (!contenidoCarrito) return;

  if (carrito.length === 0) {
    contenidoCarrito.innerHTML = `
      <div class="pt-14 text-center">
        <p class="text-4xl mb-3">🍺</p>
        <p class="text-lg font-bold text-[var(--tinta)]">Tu carrito está vacío</p>
        <p class="mt-1 text-sm text-[var(--tinta-suave)]">Agrega tus cervezas favoritas para empezar</p>
      </div>`;
    return;
  }

  let total = 0;
  let html = '<div class="space-y-3">';

  carrito.forEach((producto, indice) => {
    total += producto.precio;
    html += `
      <div class="flex justify-between items-center gap-3 border-b border-black/5 pb-3">
        <div>
          <strong class="block text-[var(--tinta)]">${producto.nombre}</strong>
          <p class="text-[var(--naranja)] font-bold text-sm">$${producto.precio.toLocaleString("es-CL")}</p>
        </div>
        <button class="text-red-500 hover:text-red-700 font-bold text-lg cursor-pointer" onclick="eliminarProducto(${indice})" aria-label="Eliminar producto">✕</button>
      </div>`;
  });

  html += `
    </div>
    <div class="mt-5 pt-4 border-t-2 border-[var(--ambar)] flex justify-between items-center">
      <strong class="text-lg text-[var(--tinta)]">Total:</strong>
      <strong class="text-lg text-[var(--naranja)]">$${total.toLocaleString("es-CL")}</strong>
    </div>
    <button class="w-full mt-5 bg-[var(--tinta)] text-white py-3 rounded-full font-bold shadow-md hover:bg-[var(--naranja)] transition-colors cursor-pointer">
      Ir a pagar 🍻
    </button>`;

  contenidoCarrito.innerHTML = html;
}

function agregarProducto(nombre, precio) {
  carrito.push({ nombre, precio });
  guardarCarrito();
  actualizarContador();
  mostrarCarrito();
  if (carritoPanel) carritoPanel.classList.add("abierto");
}

window.eliminarProducto = function (indice) {
  carrito.splice(indice, 1);
  guardarCarrito();
  actualizarContador();
  mostrarCarrito();
};

document.addEventListener("DOMContentLoaded", () => {
  actualizarContador();
  mostrarCarrito();

  document.querySelectorAll(".btn-agregar").forEach((boton) => {
    boton.addEventListener("click", () => {
      const nombre = boton.dataset.nombre;
      const precio = Number(boton.dataset.precio);
      if (nombre && precio >= 0) agregarProducto(nombre, precio);
    });
  });

  if (btnCarrito) {
    btnCarrito.addEventListener("click", () => {
      carritoPanel.classList.add("abierto");
      mostrarCarrito();
    });
  }

  if (cerrarCarrito) {
    cerrarCarrito.addEventListener("click", () => {
      carritoPanel.classList.remove("abierto");
    });
  }

  document.getElementById("cerrarCarritoOverlay")?.addEventListener("click", () => {
    carritoPanel?.classList.remove("abierto");
  });

  /* ---------- Menú hamburguesa ---------- */
  const btnMenu = document.getElementById("btnMenu");
  const menuPrincipal = document.getElementById("menuPrincipal");
  if (btnMenu && menuPrincipal) {
    const abrirMenu = (estado) => {
      menuPrincipal.setAttribute("data-open", estado ? "true" : "false");
      btnMenu.setAttribute("aria-expanded", estado ? "true" : "false");
    };
    btnMenu.addEventListener("click", (e) => {
      e.stopPropagation();
      abrirMenu(menuPrincipal.getAttribute("data-open") !== "true");
    });
    document.addEventListener("click", (e) => {
      if (!menuPrincipal.contains(e.target) && !btnMenu.contains(e.target)) abrirMenu(false);
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") abrirMenu(false);
    });
  }

  /* ---------- Filtros de catálogo ---------- */
  const botonesFiltro = document.querySelectorAll(".filtro-btn");
  const productos = document.querySelectorAll(".producto-card");

  function filtrarProductos(categoria) {
    productos.forEach((producto) => {
      const match = categoria === "todos" || producto.dataset.categoria === categoria;
      producto.classList.toggle("oculto-filtro", !match);
    });
    botonesFiltro.forEach((boton) => {
      const activo = boton.dataset.categoria === categoria;
      boton.classList.toggle("bg-[var(--tinta)]", activo);
      boton.classList.toggle("text-white", activo);
      boton.classList.toggle("border-[var(--tinta)]", activo);
    });
  }

  if (botonesFiltro.length) {
    botonesFiltro.forEach((boton) => {
      boton.addEventListener("click", () => filtrarProductos(boton.dataset.categoria));
    });

    const categoriaURL = new URLSearchParams(window.location.search).get("categoria");
    filtrarProductos(categoriaURL || "todos");
  }

  /* ---------- Login (demo) ---------- */
  const formLogin = document.getElementById("formLogin");
  const mensajeLogin = document.getElementById("mensajeLogin");

  if (formLogin) {
    formLogin.addEventListener("submit", (evento) => {
      evento.preventDefault();
      const correo = document.getElementById("correo").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!correo || !password) {
        mensajeLogin.textContent = "Debes completar todos los campos.";
        mensajeLogin.className = "mt-4 text-center font-bold text-red-500";
        return;
      }

      mensajeLogin.textContent = "¡Listo! Inicio de sesión realizado correctamente.";
      mensajeLogin.className = "mt-4 text-center font-bold text-[var(--teal)]";
      formLogin.reset();
    });
  }
});
